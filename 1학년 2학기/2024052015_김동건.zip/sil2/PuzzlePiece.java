package sil2;

public class PuzzlePiece {
    private int face_value;

    public PuzzlePiece(int value){face_value = value;}

    int faceValue(){return face_value;}

}
