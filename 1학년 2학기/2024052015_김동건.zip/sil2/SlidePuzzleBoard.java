package sil2;

public class SlidePuzzleBoard {
    private PuzzlePiece[][] board;
    private int size;

    //빈칸 좌표
    private int empty_row;
    private int empty_col;

    /** Constructor - SlidePuzzleBoard 초기 퍼즐 보드 설정
     * @param s 퍼즐 보드 크기 */
    public SlidePuzzleBoard(int s) {
        size = s;
        // size x size 보드 만들기
        board = new PuzzlePiece[size][size];
        // 퍼즐 조각 1~(size^2 -1)를 보드에 역순으로 끼우기
        int number = size * size - 1;
        for (int row = 0; row < size; row++)
            for (int col = 0; col < size; col++) {
                board[row][col] = new PuzzlePiece(number);
                number -= 1;
            }
        board[size-1][size-1] = null;
        empty_row = size-1;
        empty_col = size-1;
    }

    /** 이동이 가능하면, 퍼즐 조각을 빈칸으로 이동
     * @param w 이동하기 원하는 퍼즐 조각
     * @return 이동성공하면 true를 리턴하고 이동 실패하면 false를 리턴 */
    public boolean move(int w) {
        int row, col; // w의 위치
        // 빈칸에 주변에서 w의 위치를 찾음
        if (found(w, empty_row - 1, empty_col)) {
            row = empty_row - 1;
            col = empty_col;
        }
        else if (found(w, empty_row + 1, empty_col)) {
            row = empty_row + 1;
            col = empty_col;
        }
        else if (found(w, empty_row, empty_col - 1)) {
            row = empty_row;
            col = empty_col - 1;
        }
        else if (found(w, empty_row, empty_col + 1)) {
            row = empty_row;
            col = empty_col + 1;
        }
        else
            return false;
        // w를 빈칸에 복사
        board[empty_row][empty_col] = board[row][col];
        // 빈칸 위치를 새로 설정하고, w를 제거
        empty_row = row;
        empty_col = col;
        board[empty_row][empty_col] = null;
        return true;
    }

    /** found board[row][col]에 퍼즐 조각 v가 있는지 확인 */
    private boolean found(int v, int row, int col) {
        if (row >= 0 && row < size && col >= 0 && col < size)
            return board[row][col].faceValue() == v;
        else
            return false;
    }

    public PuzzlePiece getPuzzlePiece(int row, int col) {
        return board[row][col];
    }
}
